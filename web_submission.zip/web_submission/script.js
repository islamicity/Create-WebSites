document.querySelector(".menu-btn").addEventListener("click", showNavbar);
function showNavbar() {
  document.querySelector(".main-menu").classList.toggle("show");
}
